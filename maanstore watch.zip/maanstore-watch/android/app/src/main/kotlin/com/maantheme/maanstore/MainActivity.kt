package com.maantheme.maanstore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
