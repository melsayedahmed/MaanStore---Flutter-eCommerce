package com.maantechnology.maanwatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
