
// class Config {
//   static String websiteURL = 'https://maantechnology.com/maanstore/';
//   static String key = 'ck_b38f0f831b2f8507d710b9833655fd8501f10ac2';
//   static String secret = 'cs_4e4e6174cb964eea30b3a859857edbd29e4b4d02';
//   static String url = 'https://maantechnology.com/maanstore/wp-json/wc/v3/';
//   static String orderConfirmUrl = 'https://maantechnology.com/maanstore/checkout/order-received/';
//   static String customerURL = 'customers';
//   static String tokenURL = 'https://maantechnology.com/maanstore/wp-json/jwt-auth/v1/token';
//   static String categoryURL = 'products/categories';
//   static String productsURL = 'products';
//   static String singleProductsURL = 'products/';
//   static String customerDetails = 'customers/';
//   static String createOrderUrl = 'orders';
//   static String anOrderUrl = 'orders/';
//   static String coupons = 'coupons';
//   static String media = 'https://maantechnology.com/maanstore/wp-json/wp/v2/media?';
//   static String createReviewUrl = 'products/reviews';
//
//
// }

class Config {
  static String websiteURL = 'https://ecommerceapp.acnoo.com/maanstore/';
  static String key = 'ck_20252f55068f4f1655e064d4e12b0c6bb975c0dd';
  static String secret = 'cs_8cbe88e89ea53347c6191c360f9a97b2c6465a5d';
  static String url = 'https://ecommerceapp.acnoo.com/maanstore/wp-json/wc/v3/';
  static String customerURL = 'customers';
  static String tokenURL = 'https://ecommerceapp.acnoo.com/maanstore/wp-json/jwt-auth/v1/token';
  static String orderConfirmUrl = 'https://ecommerceapp.acnoo.com/maanstore/checkout/order-received/';
  static String categoryURL = 'products/categories';
  static String productsURL = 'products';
  static String singleProductsURL = 'products/';
  static String customerDetails = 'customers/';
  static String createOrderUrl = 'orders';
  static String anOrderUrl = 'orders/';
  static String coupons = 'coupons';
  static String media = 'https://ecommerceapp.acnoo.com/maanstore/wp-json/wp/v2/media?';
  static String createReviewUrl = 'products/reviews';

}

